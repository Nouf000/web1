<?php
if (isset($_POST['name'])) {
  $name = $_POST['name'];
  $date=date('Y-m-d H:i:s');
  // Database connection details
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "voice";

  try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO voice_text (voice_txt,date) VALUES (?,?)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(1, $name);
    $stmt->bindParam(2, $date);


    if ($stmt->execute()) {
      echo " saved successfully.";
    } else {
      echo "Error: Unable to save text .";
    }
  } catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
  }
}
?>