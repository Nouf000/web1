<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "voice";

try {
  $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT * FROM voice_text";
  $stmt = $pdo->prepare($sql);
  $stmt->execute();
  $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  if ($stmt->rowCount() > 0) {
      $data = array();
  
      foreach ($result as $row) {
          $data[] = array(
              'voice_txt' => $row['voice_txt'],
              'date' => $row['date']
          );
      }
  
      echo json_encode($data);
  } else {
      echo json_encode(array("message" => "No data found."));
  }
} catch (PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>